package pe.com.ecocleany.ecosmart.smartbins.domain.model;

public enum SmartBinStatus {
    NORMAL,
    ALMOST_FULL,
    FULL,
    OUT_OF_SERVICE
}
